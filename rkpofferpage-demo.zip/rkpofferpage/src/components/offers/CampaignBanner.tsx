import { campaign } from "@/data/offers";

export function CampaignBanner() {
  return (
    <header className="relative z-10 mb-7 min-[600px]:mb-[6.71%]">
      <h1 className="sr-only">{campaign.title}</h1>
      <img className="block h-auto w-full rounded-[1.7cqw]" src={campaign.banner} alt={campaign.bannerAlt} width={4416} height={2018} fetchPriority="high" />
    </header>
  );
}
